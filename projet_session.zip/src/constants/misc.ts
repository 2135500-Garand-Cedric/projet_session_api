export enum NodeEnvs {
  Dev = 'development',
  Test = 'test',
  Production = 'production'
}